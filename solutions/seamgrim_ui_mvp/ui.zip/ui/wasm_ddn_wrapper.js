const EXPECTED_SCHEMA = "seamgrim.state.v0";

export function parseStateJson(payload) {
  const parsed = JSON.parse(payload);
  if (parsed.schema !== EXPECTED_SCHEMA) {
    throw new Error(`Unexpected schema: ${String(parsed.schema)}`);
  }
  return parsed;
}

function nowMs() {
  if (typeof performance !== "undefined" && typeof performance.now === "function") {
    return performance.now();
  }
  return Date.now();
}

export class DdnWasmVmClient {
  constructor(vm) {
    this.vm = vm;
    this.frameId = 0;
    this.lastStepMs = null;
  }

  updateLogic(source) {
    this.vm.update_logic(source);
  }

  setRngSeed(seed) {
    this.vm.set_rng_seed(seed);
  }

  setInput(keys_pressed, last_key_name, pointer_x_i32, pointer_y_i32, dt) {
    this.vm.set_input(keys_pressed, last_key_name, pointer_x_i32, pointer_y_i32, dt);
  }

  stepOneParsed() {
    const state = parseStateJson(this.vm.step_one());
    return this.attachDerived(state, true);
  }

  stepOneWithInputParsed(keys_pressed, last_key_name, pointer_x_i32, pointer_y_i32, dt) {
    const state = parseStateJson(
      this.vm.step_one_with_input(keys_pressed, last_key_name, pointer_x_i32, pointer_y_i32, dt),
    );
    return this.attachDerived(state, true);
  }

  getStateHash() {
    return this.vm.get_state_hash();
  }

  getStateParsed() {
    const state = parseStateJson(this.vm.get_state_json());
    return this.attachDerived(state, false);
  }

  attachDerived(state, advance) {
    const now = nowMs();
    const tickTime = this.lastStepMs === null ? 0 : Math.max(0, now - this.lastStepMs);
    if (advance) {
      this.lastStepMs = now;
      const next = { ...state, frame_id: this.frameId, tick_time_ms: tickTime };
      this.frameId += 1;
      return next;
    }
    return { ...state, frame_id: this.frameId, tick_time_ms: 0 };
  }
}
