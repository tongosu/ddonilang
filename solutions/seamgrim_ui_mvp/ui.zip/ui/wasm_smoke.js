const $ = (id) => document.getElementById(id);

const KEY_BITS = {
  up: 1,
  left: 2,
  down: 4,
  right: 8,
};

let vmClient = null;
let running = false;
let loopHandle = null;
let lastFrameMs = null;
let latestGraph = null;
let latestSpace2d = null;
let latestPatch = null;
let lastState = null;

const statusBox = $("status");
const rawBox = $("raw-json");
const toggleRaw = $("toggle-raw");
const patchListBox = $("patch-list");
const paramListBox = $("param-list");
const graphCanvas = $("graph-canvas");
const gridToggle = $("graph-show-grid");
const axisToggle = $("graph-show-axis");
const patchFilterResource = $("patch-filter-resource");
const patchFilterComponent = $("patch-filter-component");
const patchFilterSignal = $("patch-filter-signal");
const patchPreferToggle = $("patch-prefer");
const paramShowFixed64 = $("param-show-fixed64");
const paramShowValue = $("param-show-value");

function setStatus(lines) {
  if (!statusBox) return;
  statusBox.textContent = lines.join("\n");
}

  function stripMetaHeader(text) {
    const lines = String(text ?? "").replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
  let idx = 0;
  while (idx < lines.length) {
    const raw = lines[idx];
    const trimmed = raw.replace(/^[ \t\uFEFF]+/, "");
    if (!trimmed) {
      idx += 1;
      continue;
    }
    if (trimmed.startsWith("#") && trimmed.includes(":")) {
      idx += 1;
      continue;
    }
    break;
  }
    return lines.slice(idx).join("\n");
  }

  function dumpSourceDebug(source) {
    const lines = String(source ?? "").replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
    const numbered = lines.map((line, idx) => `${String(idx + 1).padStart(3, " ")}: ${line}`);
    console.groupCollapsed("DDN source (debug)");
    console.log(numbered.join("\n"));
    console.log(`lines=${lines.length}, chars=${source.length}`);
    console.groupEnd();
  }

  function buildSourcePreview(source, maxLines = 30) {
    const lines = String(source ?? "").replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
    const clipped = lines.slice(0, maxLines);
    const numbered = clipped.map((line, idx) => `${String(idx + 1).padStart(3, " ")}: ${line}`);
    if (lines.length > maxLines) {
      numbered.push(`... (${lines.length - maxLines} more lines)`);
    }
    return numbered;
  }

  const WASM_CACHE_BUST = Date.now();
  let lastBuildInfo = "";
  let lastPreprocessed = "";

  async function ensureWasm(source) {
    if (vmClient) return vmClient;
    setStatus(["status: wasm loading..."]);
    const wasmModule = await import(`./wasm/ddonirang_tool.js?v=${WASM_CACHE_BUST}`);
    if (typeof wasmModule.default === "function") {
      await wasmModule.default();
    }
    const { DdnWasmVm } = wasmModule;
    if (typeof wasmModule.wasm_build_info === "function") {
      try {
        lastBuildInfo = wasmModule.wasm_build_info();
      } catch (err) {
        lastBuildInfo = `build_info error: ${String(err?.message ?? err)}`;
      }
    }
    if (typeof DdnWasmVm !== "function") {
      throw new Error("DdnWasmVm export 누락: scripts/build_wasm_tool.ps1 --features wasm 필요");
    }
  const wrapper = await import("./wasm_ddn_wrapper.js");
  const needsSource = DdnWasmVm.length > 0;
    const sourceText = stripMetaHeader(source);
    const cleaned = sourceText.trim();
    if (typeof wasmModule.wasm_preprocess_source === "function") {
      try {
        lastPreprocessed = wasmModule.wasm_preprocess_source(sourceText);
      } catch (err) {
        lastPreprocessed = `preprocess error: ${String(err?.message ?? err)}`;
      }
    }
  if (needsSource && !cleaned) {
    const fallback = "매틱:움직씨 = { 프레임수 <- 0. 프레임수 <- (프레임수 + 1). }.";
    console.warn("DDN 소스가 비어있어 최소 fallback 프로그램으로 초기화합니다.");
    const vm = new DdnWasmVm(fallback);
    vmClient = new wrapper.DdnWasmVmClient(vm);
    setStatus(["status: wasm ready (fallback) — 샘플 로드 후 '로직 적용'을 누르세요."]);
    return vmClient;
  }
    const vm = needsSource ? new DdnWasmVm(cleaned) : new DdnWasmVm();
    vmClient = new wrapper.DdnWasmVmClient(vm);
    if (!needsSource && cleaned) {
      vmClient.updateLogic(cleaned);
    }
    let buildInfo = lastBuildInfo;
    if (!buildInfo && typeof vm.get_build_info === "function") {
      try {
        buildInfo = vm.get_build_info();
      } catch (err) {
        buildInfo = `build_info error: ${String(err?.message ?? err)}`;
      }
    }
    const statusLine = buildInfo
      ? `status: wasm ready (v=${WASM_CACHE_BUST}) | ${buildInfo}`
      : `status: wasm ready (v=${WASM_CACHE_BUST})`;
    setStatus([statusLine]);
    return vmClient;
  }

function gatherInput() {
  let keys = 0;
  if ($("key-up").checked) keys |= KEY_BITS.up;
  if ($("key-left").checked) keys |= KEY_BITS.left;
  if ($("key-down").checked) keys |= KEY_BITS.down;
  if ($("key-right").checked) keys |= KEY_BITS.right;
  const lastKey = $("input-last-key").value ?? "";
  const px = Number($("input-px").value ?? 0);
  const py = Number($("input-py").value ?? 0);
  const dt = Number($("input-dt").value ?? 0);
  return {
    keys,
    lastKey,
    px: Number.isFinite(px) ? Math.trunc(px) : 0,
    py: Number.isFinite(py) ? Math.trunc(py) : 0,
    dt: Number.isFinite(dt) && dt >= 0 ? dt : 0,
  };
}

function renderState(state) {
  if (!state) return;
  lastState = state;
  const patchCount = Array.isArray(state.patch) ? state.patch.length : 0;
  const lines = [
    `state_hash: ${state.state_hash ?? "-"}`,
    `tick_id: ${state.tick_id ?? "-"}`,
    `frame_id: ${state.frame_id ?? "-"}`,
    `tick_time_ms: ${
      Number.isFinite(state.tick_time_ms) ? state.tick_time_ms.toFixed(2) : "-"
    }`,
    `patch: ${patchCount}`,
  ];
  setStatus(lines);
  if (rawBox) {
    rawBox.value = JSON.stringify(state, null, 2);
  }
  latestPatch = Array.isArray(state.patch) ? state.patch : [];
  renderPatchList(latestPatch);
  renderParamList(state);
  updateGraphFromState(state);
  updateSpace2dFromState(state);
  renderGraphOrSpace2d(latestGraph, latestSpace2d);
}

function renderPatchList(patch) {
  if (!patchListBox) return;
  if (!Array.isArray(patch) || !patch.length) {
    patchListBox.textContent = "-";
    return;
  }
  const allowResource = patchFilterResource?.checked ?? true;
  const allowComponent = patchFilterComponent?.checked ?? true;
  const allowSignal = patchFilterSignal?.checked ?? true;
  const recent = patch.slice(-20).map((op) => {
    if (!op || !op.op) return "-";
    const group = classifyPatchOp(op);
    if ((group === "resource" && !allowResource) || (group === "component" && !allowComponent)) {
      return null;
    }
    if (group === "signal" && !allowSignal) return null;
    if (op.op === "set_resource_json") {
      return `${op.op} tag=${op.tag}`;
    }
    if (op.op === "set_resource_fixed64") {
      return `${op.op} tag=${op.tag} value=${op.value}`;
    }
    if (op.op === "set_resource_value") {
      return `${op.op} tag=${op.tag} value=${op.value}`;
    }
    if (op.op === "set_component_json") {
      return `${op.op} entity=${op.entity} tag=${op.tag}`;
    }
    if (op.op === "remove_component") {
      return `${op.op} entity=${op.entity} tag=${op.tag}`;
    }
    return JSON.stringify(op);
  });
  const filtered = recent.filter((line) => line != null);
  patchListBox.textContent = filtered.length ? filtered.join("\n") : "-";
}

function classifyPatchOp(op) {
  if (!op?.op) return "other";
  if (op.op.startsWith("set_resource") || op.op === "div_assign_resource_fixed64") {
    return "resource";
  }
  if (op.op.startsWith("set_component") || op.op === "remove_component") {
    return "component";
  }
  if (op.op === "emit_signal" || op.op === "guard_violation") {
    return "signal";
  }
  return "other";
}

function updateGraphFromState(state) {
  if (!graphCanvas) return;
  let found = false;
  const preferPatch = patchPreferToggle?.checked ?? false;
  if (preferPatch && Array.isArray(state?.patch)) {
    state.patch.forEach((op) => {
      if (!op || (op.op !== "set_resource_json" && op.op !== "set_component_json")) return;
      if (typeof op.value !== "string") return;
      try {
        const obj = JSON.parse(op.value);
        if (obj?.schema === "seamgrim.graph.v0") {
          latestGraph = obj;
          found = true;
        }
      } catch (_) {
        // ignore
      }
    });
  }
  if (!found && state?.resources?.json) {
    const entries = Object.values(state.resources.json);
    for (const raw of entries) {
      if (typeof raw !== "string") continue;
      try {
        const obj = JSON.parse(raw);
        if (obj?.schema === "seamgrim.graph.v0") {
          latestGraph = obj;
          break;
        }
      } catch (_) {
        // ignore
      }
    }
  }
}

function updateSpace2dFromState(state) {
  let found = false;
  const preferPatch = patchPreferToggle?.checked ?? false;
  if (preferPatch && Array.isArray(state?.patch)) {
    state.patch.forEach((op) => {
      if (!op || (op.op !== "set_resource_json" && op.op !== "set_component_json")) return;
      if (typeof op.value !== "string") return;
      try {
        const obj = JSON.parse(op.value);
        if (obj?.schema === "seamgrim.space2d.v0") {
          latestSpace2d = obj;
          found = true;
        }
      } catch (_) {
        // ignore
      }
    });
  }
  if (!found && state?.resources?.json) {
    const entries = Object.values(state.resources.json);
    for (const raw of entries) {
      if (typeof raw !== "string") continue;
      try {
        const obj = JSON.parse(raw);
        if (obj?.schema === "seamgrim.space2d.v0") {
          latestSpace2d = obj;
          break;
        }
      } catch (_) {
        // ignore
      }
    }
  }
}

function renderParamList(state) {
  if (!paramListBox) return;
  const showFixed = paramShowFixed64?.checked ?? true;
  const showValue = paramShowValue?.checked ?? true;
  const lines = [];
  if (showFixed && state?.resources?.fixed64) {
    const entries = Object.entries(state.resources.fixed64).sort(([a], [b]) => a.localeCompare(b));
    entries.forEach(([tag, value]) => {
      lines.push(`fixed64 ${tag} = ${value}`);
    });
  }
  if (showValue && state?.resources?.value) {
    const entries = Object.entries(state.resources.value).sort(([a], [b]) => a.localeCompare(b));
    entries.forEach(([tag, value]) => {
      lines.push(`value ${tag} = ${value}`);
    });
  }
  paramListBox.textContent = lines.length ? lines.join("\n") : "-";
}

function normalizePoints(points) {
  if (!Array.isArray(points)) return [];
  const out = [];
  points.forEach((pt) => {
    if (Array.isArray(pt) && pt.length >= 2) {
      out.push({ x: Number(pt[0]), y: Number(pt[1]) });
      return;
    }
    if (pt && Number.isFinite(pt.x) && Number.isFinite(pt.y)) {
      out.push({ x: Number(pt.x), y: Number(pt.y) });
    }
  });
  return out.filter((pt) => Number.isFinite(pt.x) && Number.isFinite(pt.y));
}

function renderGraphOrSpace2d(graph, space2d) {
  if (!graphCanvas) return;
  if (graph) {
    renderGraph(graph);
    return;
  }
  renderSpace2d(space2d);
}

function renderGraph(graph) {
  if (!graphCanvas) return;
  const ctx = graphCanvas.getContext("2d");
  const w = graphCanvas.width;
  const h = graphCanvas.height;
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = "#0b1020";
  ctx.fillRect(0, 0, w, h);
  if (!graph || !Array.isArray(graph.series) || graph.series.length === 0) {
    ctx.fillStyle = "#94a3b8";
    ctx.font = "12px 'IBM Plex Mono', ui-monospace";
    ctx.fillText("graph: -", 12, 20);
    return;
  }
  const points = normalizePoints(graph.series[0].points ?? []);
  if (!points.length) {
    ctx.fillStyle = "#94a3b8";
    ctx.font = "12px 'IBM Plex Mono', ui-monospace";
    ctx.fillText("graph: (no points)", 12, 20);
    return;
  }
  let xMin = graph?.axis?.x_min;
  let xMax = graph?.axis?.x_max;
  let yMin = graph?.axis?.y_min;
  let yMax = graph?.axis?.y_max;
  if (![xMin, xMax, yMin, yMax].every(Number.isFinite)) {
    xMin = Math.min(...points.map((p) => p.x));
    xMax = Math.max(...points.map((p) => p.x));
    yMin = Math.min(...points.map((p) => p.y));
    yMax = Math.max(...points.map((p) => p.y));
  }
  if (xMax === xMin) xMax = xMin + 1;
  if (yMax === yMin) yMax = yMin + 1;
  const pad = 28;
  const scaleX = (w - pad * 2) / (xMax - xMin);
  const scaleY = (h - pad * 2) / (yMax - yMin);

  const showAxis = axisToggle?.checked ?? true;
  const showGrid = gridToggle?.checked ?? true;
  if (showGrid) {
    ctx.strokeStyle = "rgba(148,163,184,0.15)";
    ctx.lineWidth = 1;
    for (let i = 1; i <= 4; i += 1) {
      const gx = pad + ((w - pad * 2) * i) / 5;
      const gy = pad + ((h - pad * 2) * i) / 5;
      ctx.beginPath();
      ctx.moveTo(gx, pad);
      ctx.lineTo(gx, h - pad);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(pad, gy);
      ctx.lineTo(w - pad, gy);
      ctx.stroke();
    }
  }
  if (showAxis) {
    ctx.strokeStyle = "#1f2a44";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(pad, pad);
    ctx.lineTo(pad, h - pad);
    ctx.lineTo(w - pad, h - pad);
    ctx.stroke();
    if (xMin < 0 && xMax > 0) {
      const x0 = pad + (0 - xMin) * scaleX;
      ctx.beginPath();
      ctx.moveTo(x0, pad);
      ctx.lineTo(x0, h - pad);
      ctx.stroke();
    }
    if (yMin < 0 && yMax > 0) {
      const y0 = h - pad - (0 - yMin) * scaleY;
      ctx.beginPath();
      ctx.moveTo(pad, y0);
      ctx.lineTo(w - pad, y0);
      ctx.stroke();
    }
  }

  ctx.strokeStyle = "#67e8f9";
  ctx.lineWidth = 2;
  ctx.beginPath();
  points.forEach((pt, idx) => {
    const x = pad + (pt.x - xMin) * scaleX;
    const y = h - pad - (pt.y - yMin) * scaleY;
    if (idx === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.stroke();

  ctx.fillStyle = "#e2e8f0";
  ctx.font = "11px 'IBM Plex Mono', ui-monospace";
  ctx.fillText(`x:[${xMin.toFixed(2)}, ${xMax.toFixed(2)}]`, pad, 16);
  ctx.fillText(`y:[${yMin.toFixed(2)}, ${yMax.toFixed(2)}]`, pad, 30);
}

function renderSpace2d(space2d) {
  const ctx = graphCanvas.getContext("2d");
  const w = graphCanvas.width;
  const h = graphCanvas.height;
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = "#0b1020";
  ctx.fillRect(0, 0, w, h);
  if (!space2d) {
    ctx.fillStyle = "#94a3b8";
    ctx.font = "12px 'IBM Plex Mono', ui-monospace";
    ctx.fillText("graph/space2d: -", 12, 20);
    return;
  }
  const points = normalizePoints(space2d.points ?? []);
  const drawlist = Array.isArray(space2d.drawlist) ? space2d.drawlist : [];
  const shapes = Array.isArray(space2d.shapes) ? space2d.shapes : drawlist;
  const rangePoints = [...points];
  shapes.forEach((shape) => {
    if (!shape) return;
    if (shape.kind === "line") {
      rangePoints.push({ x: Number(shape.x1), y: Number(shape.y1) });
      rangePoints.push({ x: Number(shape.x2), y: Number(shape.y2) });
    } else if (shape.kind === "circle") {
      const cx = Number(shape.x ?? shape.cx);
      const cy = Number(shape.y ?? shape.cy);
      const r = Number(shape.r);
      if ([cx, cy, r].every(Number.isFinite)) {
        rangePoints.push({ x: cx - r, y: cy - r });
        rangePoints.push({ x: cx + r, y: cy + r });
      }
    } else if (shape.kind === "rect") {
      const x = Number(shape.x ?? shape.x0);
      const y = Number(shape.y ?? shape.y0);
      const rw = Number(shape.w ?? shape.width);
      const rh = Number(shape.h ?? shape.height);
      if ([x, y, rw, rh].every(Number.isFinite)) {
        rangePoints.push({ x, y });
        rangePoints.push({ x: x + rw, y: y + rh });
      }
    } else if (shape.kind === "text" || shape.kind === "point") {
      const x = Number(shape.x);
      const y = Number(shape.y);
      if ([x, y].every(Number.isFinite)) {
        rangePoints.push({ x, y });
      }
    }
  });
  if (!rangePoints.length) {
    ctx.fillStyle = "#94a3b8";
    ctx.font = "12px 'IBM Plex Mono', ui-monospace";
    ctx.fillText("space2d: (no points)", 12, 20);
    return;
  }
    const cam = space2d?.camera ?? null;
    let xMin = Number(cam?.x_min);
    let xMax = Number(cam?.x_max);
    let yMin = Number(cam?.y_min);
    let yMax = Number(cam?.y_max);
    if (![xMin, xMax, yMin, yMax].every(Number.isFinite)) {
      xMin = Math.min(...rangePoints.map((p) => p.x));
      xMax = Math.max(...rangePoints.map((p) => p.x));
      yMin = Math.min(...rangePoints.map((p) => p.y));
      yMax = Math.max(...rangePoints.map((p) => p.y));
    }
  const pad = 28;
  const scaleX = (w - pad * 2) / (xMax - xMin || 1);
  const scaleY = (h - pad * 2) / (yMax - yMin || 1);

  ctx.strokeStyle = "#1f2a44";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(pad, pad);
  ctx.lineTo(pad, h - pad);
  ctx.lineTo(w - pad, h - pad);
  ctx.stroke();

  ctx.fillStyle = "#facc15";
  points.forEach((pt) => {
    const x = pad + (pt.x - xMin) * scaleX;
    const y = h - pad - (pt.y - yMin) * scaleY;
    ctx.beginPath();
    ctx.arc(x, y, 3, 0, Math.PI * 2);
    ctx.fill();
  });

  ctx.strokeStyle = "#a78bfa";
  shapes.forEach((shape) => {
    if (!shape) return;
    if (shape.kind === "line") {
      const x1 = pad + (Number(shape.x1) - xMin) * scaleX;
      const y1 = h - pad - (Number(shape.y1) - yMin) * scaleY;
      const x2 = pad + (Number(shape.x2) - xMin) * scaleX;
      const y2 = h - pad - (Number(shape.y2) - yMin) * scaleY;
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
    } else if (shape.kind === "circle") {
      const cx = Number(shape.x ?? shape.cx);
      const cy = Number(shape.y ?? shape.cy);
      const r = Number(shape.r);
      if (![cx, cy, r].every(Number.isFinite)) return;
      const x = pad + (cx - xMin) * scaleX;
      const y = h - pad - (cy - yMin) * scaleY;
      const rr = Math.max(1, r * Math.min(scaleX, scaleY));
      ctx.beginPath();
      ctx.arc(x, y, rr, 0, Math.PI * 2);
      ctx.stroke();
    } else if (shape.kind === "rect") {
      const x = Number(shape.x ?? shape.x0);
      const y = Number(shape.y ?? shape.y0);
      const rw = Number(shape.w ?? shape.width);
      const rh = Number(shape.h ?? shape.height);
      if (![x, y, rw, rh].every(Number.isFinite)) return;
      const x0 = pad + (x - xMin) * scaleX;
      const y0 = h - pad - (y - yMin) * scaleY;
      const w0 = rw * scaleX;
      const h0 = rh * scaleY;
      const fill = shape.fill ?? shape.fill_color ?? null;
      const stroke = shape.color ?? shape.stroke ?? "#a78bfa";
      if (fill) {
        ctx.fillStyle = String(fill);
        ctx.fillRect(x0, y0 - h0, w0, h0);
      }
      ctx.strokeStyle = String(stroke);
      ctx.strokeRect(x0, y0 - h0, w0, h0);
    } else if (shape.kind === "text") {
      const x = Number(shape.x);
      const y = Number(shape.y);
      if (![x, y].every(Number.isFinite)) return;
      const text = shape.text ?? shape.label ?? "";
      if (!text) return;
      const x0 = pad + (x - xMin) * scaleX;
      const y0 = h - pad - (y - yMin) * scaleY;
      const size = Number(shape.size);
      const fontSize = Number.isFinite(size) ? Math.max(8, size) : 11;
      ctx.fillStyle = String(shape.color ?? "#e2e8f0");
      ctx.font = `${fontSize}px 'IBM Plex Mono', ui-monospace`;
      ctx.fillText(String(text), x0, y0);
    }
  });

  ctx.fillStyle = "#e2e8f0";
  ctx.font = "11px 'IBM Plex Mono', ui-monospace";
  ctx.fillText("space2d (fallback)", pad, 16);
}

async function applyLogic() {
  const source = $("ddn-source").value ?? "";
  const body = stripMetaHeader(source);
  const client = await ensureWasm(body);
  client.updateLogic(body);
  const state = client.getStateParsed();
  renderState(state);
}

async function stepOnce() {
  const source = $("ddn-source").value ?? "";
  const body = stripMetaHeader(source);
  const client = await ensureWasm(body);
  const { keys, lastKey, px, py, dt } = gatherInput();
  const state = client.stepOneWithInputParsed(keys, lastKey, px, py, dt);
  renderState(state);
}

function startLoop() {
  if (running) return;
  running = true;
  lastFrameMs = null;
  const tick = (ts) => {
    if (!running) {
      loopHandle = null;
      return;
    }
    const now = typeof ts === "number" ? ts : performance.now();
    const fps = Math.max(1, Number($("input-fps").value ?? 30) || 30);
    const interval = 1000 / fps;
    if (lastFrameMs !== null && now - lastFrameMs < interval) {
      loopHandle = requestAnimationFrame(tick);
      return;
    }
    lastFrameMs = now;
    stepOnce().catch((err) => {
      setStatus([`status: step failed`, String(err?.message ?? err)]);
      running = false;
      loopHandle = null;
    });
    loopHandle = requestAnimationFrame(tick);
  };
  loopHandle = requestAnimationFrame(tick);
}

function stopLoop() {
  running = false;
  if (loopHandle) {
    cancelAnimationFrame(loopHandle);
    loopHandle = null;
  }
}

  async function loadSample() {
    const target = "../samples/01_line_graph.ddn";
    const cacheBust = `v=${Date.now()}`;
    const res = await fetch(`${target}?${cacheBust}`, { cache: "no-store" });
  if (!res.ok) {
    setStatus([`status: sample load failed`, `${res.status} ${res.statusText}`, `path: ${target}`]);
    return;
  }
  const text = await res.text();
  $("ddn-source").value = text;
  setStatus([`status: sample loaded (${target})`]);
}

if (window.location.protocol === "file:") {
  setStatus([
    "status: file:// 프로토콜 감지",
    "WASM/ES module은 HTTP 서버가 필요합니다.",
    "python -m http.server 8080  또는  npx serve .",
    "이후 http://localhost:8080/wasm_smoke.html 로 접속하세요.",
  ]);
}

if (toggleRaw) {
  toggleRaw.addEventListener("change", () => {
    if (!rawBox) return;
    rawBox.classList.toggle("hidden", !toggleRaw.checked);
  });
}
if (patchPreferToggle) {
  patchPreferToggle.addEventListener("change", () => {
    if (lastState) renderState(lastState);
  });
}
if (paramShowFixed64) {
  paramShowFixed64.addEventListener("change", () => {
    if (lastState) renderParamList(lastState);
  });
}
if (paramShowValue) {
  paramShowValue.addEventListener("change", () => {
    if (lastState) renderParamList(lastState);
  });
}

  $("btn-init").addEventListener("click", () => {
    const source = $("ddn-source").value ?? "";
    const body = stripMetaHeader(source);
    ensureWasm(body).catch((err) => {
      dumpSourceDebug(body);
      const preview = buildSourcePreview(body, 30);
      const header = lastBuildInfo
        ? `${String(err)} | ${lastBuildInfo}`
        : String(err);
      const preprocessedPreview = buildSourcePreview(lastPreprocessed, 30);
      setStatus([
        header,
        "source preview:",
        ...preview,
        "preprocess preview:",
        ...preprocessedPreview,
      ]);
    });
  });
$("btn-apply").addEventListener("click", () => applyLogic().catch((err) => setStatus([String(err)])));
$("btn-step").addEventListener("click", () => stepOnce().catch((err) => setStatus([String(err)])));
$("btn-start").addEventListener("click", startLoop);
$("btn-stop").addEventListener("click", stopLoop);
$("btn-load-sample").addEventListener("click", () => loadSample().catch((err) => setStatus([String(err)])));

if (gridToggle) gridToggle.addEventListener("change", () => renderGraphOrSpace2d(latestGraph, latestSpace2d));
if (axisToggle) axisToggle.addEventListener("change", () => renderGraphOrSpace2d(latestGraph, latestSpace2d));
if (patchFilterResource) patchFilterResource.addEventListener("change", () => renderPatchList(latestPatch));
if (patchFilterComponent) patchFilterComponent.addEventListener("change", () => renderPatchList(latestPatch));
if (patchFilterSignal) patchFilterSignal.addEventListener("change", () => renderPatchList(latestPatch));
