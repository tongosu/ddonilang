// DDN Playground — educational DDN runtime with sample management
// Based on wasm_smoke.js, refactored for playground use.

const $ = (id) => document.getElementById(id);

// ──────────────────────────────────────────────
// Sample manifest (extend this for curriculum)
// ──────────────────────────────────────────────
const SAMPLES = [
  {
    id: "moving_dot",
    label: "움직이는 점 (기본)",
    file: "../samples/01_line_graph.ddn",
    description: "프레임수로 점이 대각선 이동합니다.",
    category: "기초",
    source: [
      "#이름: seamgrim_ui_mvp_moving_dot_sample",
      "#설명: 프레임수로 점이 대각선 이동(모듈로 wrap).",
      "",
      "그릇채비: {",
      "  프레임수:수 <- 0.",
      "}.",
      "",
      "매틱:움직씨 = {",
      "  보개_그림판_가로 <- 200.",
      "  보개_그림판_세로 <- 120.",
      "",
      '  rect <- ("결", "#보개/2D.Rect", "x", (20 + (프레임수 % 160)), "y", (20 + ((프레임수 * 2) % 80)), "w", 6, "h", 6, "채움색", "#f59e0bff") 짝맞춤.',
      "  보개_그림판_목록 <- (rect) 차림.",
      "",
      "  프레임수 <- (프레임수 + 1).",
      "}.",
    ].join("\n"),
  },
  {
    id: "line_graph_export",
    label: "직선 그래프",
    file: "../samples/01_line_graph_export.ddn",
    description: "y = 2x + 1 직선을 그립니다.",
    category: "그래프",
    source: [
      "#이름: seamgrim_ui_mvp_export_line_graph",
      "#설명: UI 연동용 점열 출력",
      "",
      "직선 = (#ascii1) 수식{ y = 2*x + 1 }.",
      "",
      "x목록 <- (0, 4, 1) 범위.",
      "",
      "(x) x목록에 대해: {",
      "  y <- (x=x)인 직선 풀기.",
      "  x 보여주기.",
      "  y 보여주기.",
      "}.",
    ].join("\n"),
  },
  {
    id: "parabola",
    label: "포물선",
    file: "../samples/02_parabola_export.ddn",
    description: "y = ax^2 + bx + c 포물선을 그립니다.",
    category: "그래프",
    source: [
      "#이름: seamgrim_ui_mvp_export_parabola",
      "#설명: UI 연동용 포물선 점열 출력",
      "",
      "포물선 = (#ascii1) 수식{ y = a x^2 + b x + c }.",
      "",
      "a <- -1.",
      "b <- 4.",
      "c <- 0.",
      "",
      "x목록 <- (0, 4, 1) 범위.",
      "",
      "(x) x목록에 대해: {",
      "  y <- (a=a, b=b, c=c, x=x)인 포물선 풀기.",
      "  x 보여주기.",
      "  y 보여주기.",
      "}.",
    ].join("\n"),
  },
  {
    id: "time_motion",
    label: "등가속도 운동",
    file: "../samples/03_time_motion_export.ddn",
    description: "시간축 등가속도 점열을 출력합니다.",
    category: "물리",
    source: [
      "#이름: seamgrim_ui_mvp_export_time_motion",
      "#설명: t축(시간) 점열 출력(등가속도)",
      "",
      "운동 = (#ascii1) 수식{ y = a t^2 + b t + c }.",
      "",
      "a <- 0.5.",
      "b <- 2.",
      "c <- 1.",
      "",
      "t목록 <- (0, 5, 0.5) 범위.",
      "",
      "(t) t목록에 대해: {",
      "  y <- (a=a, b=b, c=c, t=t)인 운동 풀기.",
      "  t 보여주기.",
      "  y 보여주기.",
      "}.",
    ].join("\n"),
  },
  {
    id: "space2d_helpers",
    label: "Space2D 도형 헬퍼",
    file: "../samples/03_space2d_gaji_helpers.ddn",
    description: "선/원/점/글/화살표 헬퍼 예제입니다.",
    category: "고급",
    source: null,
  },
];

// ──────────────────────────────────────────────
// Key bits for input
// ──────────────────────────────────────────────
const KEY_BITS = { up: 1, left: 2, down: 4, right: 8 };

// ──────────────────────────────────────────────
// DOM references
// ──────────────────────────────────────────────
const statusBox = $("status");
const rawBox = $("raw-json");
const toggleRaw = $("toggle-raw");
const errorBox = $("error-box");
const graphCanvas = $("graph-canvas");
const gridToggle = $("graph-show-grid");
const axisToggle = $("graph-show-axis");
const patchPreferToggle = $("patch-prefer");
const paramShowFixed64 = $("param-show-fixed64");
const paramShowValue = $("param-show-value");
const sampleSelect = $("sample-select");
const guideSidebar = $("guide-sidebar");

// ──────────────────────────────────────────────
// State
// ──────────────────────────────────────────────
let vmClient = null;
let running = false;
let loopHandle = null;
let lastFrameMs = null;
let latestGraph = null;
let latestSpace2d = null;
let latestPatch = null;
let lastState = null;
let lastBuildInfo = "";
let lastPreprocessed = "";

const WASM_CACHE_BUST = Date.now();

// ──────────────────────────────────────────────
// Sample dropdown setup
// ──────────────────────────────────────────────
function populateSampleDropdown() {
  if (!sampleSelect) return;
  let lastCat = "";
  let optgroup = null;
  SAMPLES.forEach((s) => {
    if (s.category !== lastCat) {
      optgroup = document.createElement("optgroup");
      optgroup.label = s.category;
      sampleSelect.appendChild(optgroup);
      lastCat = s.category;
    }
    const opt = document.createElement("option");
    opt.value = s.id;
    opt.textContent = s.label;
    if (s.description) opt.title = s.description;
    (optgroup || sampleSelect).appendChild(opt);
  });
}

// ──────────────────────────────────────────────
// Guide sidebar toggle
// ──────────────────────────────────────────────
function toggleGuide() {
  if (guideSidebar) {
    guideSidebar.classList.toggle("collapsed");
  }
}

// ──────────────────────────────────────────────
// Status / Error display
// ──────────────────────────────────────────────
function setStatus(lines) {
  if (!statusBox) return;
  statusBox.textContent = lines.join("\n");
}

function showError(message) {
  if (!errorBox) return;
  errorBox.textContent = message;
  errorBox.classList.add("visible");
}

function clearError() {
  if (!errorBox) return;
  errorBox.textContent = "";
  errorBox.classList.remove("visible");
}

// ──────────────────────────────────────────────
// Source helpers
// ──────────────────────────────────────────────
function stripMetaHeader(text) {
  const lines = String(text ?? "").replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
  let idx = 0;
  while (idx < lines.length) {
    const trimmed = lines[idx].replace(/^[ \t\uFEFF]+/, "");
    if (!trimmed) { idx += 1; continue; }
    if (trimmed.startsWith("#") && trimmed.includes(":")) { idx += 1; continue; }
    break;
  }
  return lines.slice(idx).join("\n");
}

function buildSourcePreview(source, maxLines = 30) {
  const lines = String(source ?? "").replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
  const clipped = lines.slice(0, maxLines);
  const numbered = clipped.map((line, idx) => `${String(idx + 1).padStart(3, " ")}: ${line}`);
  if (lines.length > maxLines) {
    numbered.push(`... (${lines.length - maxLines} more lines)`);
  }
  return numbered;
}

// ──────────────────────────────────────────────
// WASM initialization
// ──────────────────────────────────────────────
async function ensureWasm(source) {
  if (vmClient) return vmClient;
  setStatus(["status: wasm loading..."]);
  clearError();
  const wasmModule = await import(`./wasm/ddonirang_tool.js?v=${WASM_CACHE_BUST}`);
  if (typeof wasmModule.default === "function") {
    await wasmModule.default();
  }
  const { DdnWasmVm } = wasmModule;
  if (typeof wasmModule.wasm_build_info === "function") {
    try { lastBuildInfo = wasmModule.wasm_build_info(); }
    catch (err) { lastBuildInfo = `build_info error: ${String(err?.message ?? err)}`; }
  }
  if (typeof DdnWasmVm !== "function") {
    throw new Error("DdnWasmVm export missing — wasm build with --features wasm required");
  }
  const wrapper = await import("./wasm_ddn_wrapper.js");
  const needsSource = DdnWasmVm.length > 0;
  const sourceText = stripMetaHeader(source);
  const cleaned = sourceText.trim();
  if (typeof wasmModule.wasm_preprocess_source === "function") {
    try { lastPreprocessed = wasmModule.wasm_preprocess_source(sourceText); }
    catch (err) { lastPreprocessed = `preprocess error: ${String(err?.message ?? err)}`; }
  }
  if (needsSource && !cleaned) {
    const fallback = "매틱:움직씨 = { 프레임수 <- 0. 프레임수 <- (프레임수 + 1). }.";
    console.warn("DDN source empty — using minimal fallback");
    const vm = new DdnWasmVm(fallback);
    vmClient = new wrapper.DdnWasmVmClient(vm);
    setStatus(["status: wasm ready (fallback)", "샘플을 선택하고 '로직 적용'을 누르세요."]);
    return vmClient;
  }
  const vm = needsSource ? new DdnWasmVm(cleaned) : new DdnWasmVm();
  vmClient = new wrapper.DdnWasmVmClient(vm);
  if (!needsSource && cleaned) {
    vmClient.updateLogic(cleaned);
  }
  let buildInfo = lastBuildInfo;
  if (!buildInfo && typeof vm.get_build_info === "function") {
    try { buildInfo = vm.get_build_info(); }
    catch (err) { buildInfo = `build_info error: ${String(err?.message ?? err)}`; }
  }
  const statusLine = buildInfo
    ? `status: wasm ready | ${buildInfo}`
    : `status: wasm ready`;
  setStatus([statusLine]);
  return vmClient;
}

// ──────────────────────────────────────────────
// Input gathering
// ──────────────────────────────────────────────
function gatherInput() {
  let keys = 0;
  if ($("key-up")?.checked) keys |= KEY_BITS.up;
  if ($("key-left")?.checked) keys |= KEY_BITS.left;
  if ($("key-down")?.checked) keys |= KEY_BITS.down;
  if ($("key-right")?.checked) keys |= KEY_BITS.right;
  const lastKey = $("input-last-key")?.value ?? "";
  const px = Number($("input-px")?.value ?? 0);
  const py = Number($("input-py")?.value ?? 0);
  const dt = Number($("input-dt")?.value ?? 0);
  return {
    keys,
    lastKey,
    px: Number.isFinite(px) ? Math.trunc(px) : 0,
    py: Number.isFinite(py) ? Math.trunc(py) : 0,
    dt: Number.isFinite(dt) && dt >= 0 ? dt : 0,
  };
}

// ──────────────────────────────────────────────
// State rendering
// ──────────────────────────────────────────────
function renderState(state) {
  if (!state) return;
  lastState = state;
  clearError();
  const patchCount = Array.isArray(state.patch) ? state.patch.length : 0;
  const lines = [
    `state_hash: ${state.state_hash ?? "-"}`,
    `tick_id: ${state.tick_id ?? "-"}`,
    `frame_id: ${state.frame_id ?? "-"}`,
    `tick_time_ms: ${Number.isFinite(state.tick_time_ms) ? state.tick_time_ms.toFixed(2) : "-"}`,
    `patch: ${patchCount}`,
  ];
  setStatus(lines);
  if (rawBox) rawBox.value = JSON.stringify(state, null, 2);
  latestPatch = Array.isArray(state.patch) ? state.patch : [];
  renderParamList(state);
  updateGraphFromState(state);
  updateSpace2dFromState(state);
  renderGraphOrSpace2d(latestGraph, latestSpace2d);
}

function renderParamList(state) {
  const showFixed = paramShowFixed64?.checked ?? true;
  const showValue = paramShowValue?.checked ?? true;
  const lines = [];
  if (showFixed && state?.resources?.fixed64) {
    const entries = Object.entries(state.resources.fixed64).sort(([a], [b]) => a.localeCompare(b));
    entries.forEach(([tag, value]) => { lines.push(`fixed64 ${tag} = ${value}`); });
  }
  if (showValue && state?.resources?.value) {
    const entries = Object.entries(state.resources.value).sort(([a], [b]) => a.localeCompare(b));
    entries.forEach(([tag, value]) => { lines.push(`value ${tag} = ${value}`); });
  }
  // Append param info to status
  if (lines.length) {
    const current = statusBox?.textContent ?? "";
    statusBox.textContent = current + "\n---\n" + lines.join("\n");
  }
}

// ──────────────────────────────────────────────
// Graph / Space2D extraction from state
// ──────────────────────────────────────────────
function updateGraphFromState(state) {
  if (!graphCanvas) return;
  let found = false;
  const preferPatch = patchPreferToggle?.checked ?? false;
  if (preferPatch && Array.isArray(state?.patch)) {
    state.patch.forEach((op) => {
      if (!op || (op.op !== "set_resource_json" && op.op !== "set_component_json")) return;
      if (typeof op.value !== "string") return;
      try {
        const obj = JSON.parse(op.value);
        if (obj?.schema === "seamgrim.graph.v0") { latestGraph = obj; found = true; }
      } catch (_) {}
    });
  }
  if (!found && state?.resources?.json) {
    const entries = Object.values(state.resources.json);
    for (const raw of entries) {
      if (typeof raw !== "string") continue;
      try {
        const obj = JSON.parse(raw);
        if (obj?.schema === "seamgrim.graph.v0") { latestGraph = obj; break; }
      } catch (_) {}
    }
  }
}

function updateSpace2dFromState(state) {
  let found = false;
  const preferPatch = patchPreferToggle?.checked ?? false;
  if (preferPatch && Array.isArray(state?.patch)) {
    state.patch.forEach((op) => {
      if (!op || (op.op !== "set_resource_json" && op.op !== "set_component_json")) return;
      if (typeof op.value !== "string") return;
      try {
        const obj = JSON.parse(op.value);
        if (obj?.schema === "seamgrim.space2d.v0") { latestSpace2d = obj; found = true; }
      } catch (_) {}
    });
  }
  if (!found && state?.resources?.json) {
    const entries = Object.values(state.resources.json);
    for (const raw of entries) {
      if (typeof raw !== "string") continue;
      try {
        const obj = JSON.parse(raw);
        if (obj?.schema === "seamgrim.space2d.v0") { latestSpace2d = obj; break; }
      } catch (_) {}
    }
  }
}

// ──────────────────────────────────────────────
// Graph rendering
// ──────────────────────────────────────────────
function normalizePoints(points) {
  if (!Array.isArray(points)) return [];
  const out = [];
  points.forEach((pt) => {
    if (Array.isArray(pt) && pt.length >= 2) {
      out.push({ x: Number(pt[0]), y: Number(pt[1]) });
      return;
    }
    if (pt && Number.isFinite(pt.x) && Number.isFinite(pt.y)) {
      out.push({ x: Number(pt.x), y: Number(pt.y) });
    }
  });
  return out.filter((pt) => Number.isFinite(pt.x) && Number.isFinite(pt.y));
}

function renderGraphOrSpace2d(graph, space2d) {
  if (!graphCanvas) return;
  if (graph) { renderGraph(graph); return; }
  renderSpace2d(space2d);
}

function renderGraph(graph) {
  if (!graphCanvas) return;
  const ctx = graphCanvas.getContext("2d");
  const w = graphCanvas.width;
  const h = graphCanvas.height;
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = "#0b1020";
  ctx.fillRect(0, 0, w, h);
  if (!graph || !Array.isArray(graph.series) || graph.series.length === 0) {
    ctx.fillStyle = "#94a3b8";
    ctx.font = "12px 'IBM Plex Mono', ui-monospace";
    ctx.fillText("graph: -", 12, 20);
    return;
  }
  const points = normalizePoints(graph.series[0].points ?? []);
  if (!points.length) {
    ctx.fillStyle = "#94a3b8";
    ctx.font = "12px 'IBM Plex Mono', ui-monospace";
    ctx.fillText("graph: (no points)", 12, 20);
    return;
  }
  let xMin = graph?.axis?.x_min;
  let xMax = graph?.axis?.x_max;
  let yMin = graph?.axis?.y_min;
  let yMax = graph?.axis?.y_max;
  if (![xMin, xMax, yMin, yMax].every(Number.isFinite)) {
    xMin = Math.min(...points.map((p) => p.x));
    xMax = Math.max(...points.map((p) => p.x));
    yMin = Math.min(...points.map((p) => p.y));
    yMax = Math.max(...points.map((p) => p.y));
  }
  if (xMax === xMin) xMax = xMin + 1;
  if (yMax === yMin) yMax = yMin + 1;
  const pad = 28;
  const scaleX = (w - pad * 2) / (xMax - xMin);
  const scaleY = (h - pad * 2) / (yMax - yMin);

  const showAxis = axisToggle?.checked ?? true;
  const showGrid = gridToggle?.checked ?? true;
  if (showGrid) {
    ctx.strokeStyle = "rgba(148,163,184,0.15)";
    ctx.lineWidth = 1;
    for (let i = 1; i <= 4; i += 1) {
      const gx = pad + ((w - pad * 2) * i) / 5;
      const gy = pad + ((h - pad * 2) * i) / 5;
      ctx.beginPath(); ctx.moveTo(gx, pad); ctx.lineTo(gx, h - pad); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(pad, gy); ctx.lineTo(w - pad, gy); ctx.stroke();
    }
  }
  if (showAxis) {
    ctx.strokeStyle = "#1f2a44";
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(pad, pad); ctx.lineTo(pad, h - pad); ctx.lineTo(w - pad, h - pad); ctx.stroke();
    if (xMin < 0 && xMax > 0) {
      const x0 = pad + (0 - xMin) * scaleX;
      ctx.beginPath(); ctx.moveTo(x0, pad); ctx.lineTo(x0, h - pad); ctx.stroke();
    }
    if (yMin < 0 && yMax > 0) {
      const y0 = h - pad - (0 - yMin) * scaleY;
      ctx.beginPath(); ctx.moveTo(pad, y0); ctx.lineTo(w - pad, y0); ctx.stroke();
    }
  }

  ctx.strokeStyle = "#67e8f9";
  ctx.lineWidth = 2;
  ctx.beginPath();
  points.forEach((pt, idx) => {
    const x = pad + (pt.x - xMin) * scaleX;
    const y = h - pad - (pt.y - yMin) * scaleY;
    if (idx === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  });
  ctx.stroke();

  ctx.fillStyle = "#e2e8f0";
  ctx.font = "11px 'IBM Plex Mono', ui-monospace";
  ctx.fillText(`x:[${xMin.toFixed(2)}, ${xMax.toFixed(2)}]`, pad, 16);
  ctx.fillText(`y:[${yMin.toFixed(2)}, ${yMax.toFixed(2)}]`, pad, 30);
}

function renderSpace2d(space2d) {
  const ctx = graphCanvas.getContext("2d");
  const w = graphCanvas.width;
  const h = graphCanvas.height;
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = "#0b1020";
  ctx.fillRect(0, 0, w, h);
  if (!space2d) {
    ctx.fillStyle = "#94a3b8";
    ctx.font = "12px 'IBM Plex Mono', ui-monospace";
    ctx.fillText("graph/space2d: -", 12, 20);
    return;
  }
  const points = normalizePoints(space2d.points ?? []);
  const drawlist = Array.isArray(space2d.drawlist) ? space2d.drawlist : [];
  const shapes = Array.isArray(space2d.shapes) ? space2d.shapes : drawlist;
  const rangePoints = [...points];
  shapes.forEach((shape) => {
    if (!shape) return;
    if (shape.kind === "line") {
      rangePoints.push({ x: Number(shape.x1), y: Number(shape.y1) });
      rangePoints.push({ x: Number(shape.x2), y: Number(shape.y2) });
    } else if (shape.kind === "circle") {
      const cx = Number(shape.x ?? shape.cx);
      const cy = Number(shape.y ?? shape.cy);
      const r = Number(shape.r);
      if ([cx, cy, r].every(Number.isFinite)) {
        rangePoints.push({ x: cx - r, y: cy - r });
        rangePoints.push({ x: cx + r, y: cy + r });
      }
    } else if (shape.kind === "rect") {
      const x = Number(shape.x ?? shape.x0);
      const y = Number(shape.y ?? shape.y0);
      const rw = Number(shape.w ?? shape.width);
      const rh = Number(shape.h ?? shape.height);
      if ([x, y, rw, rh].every(Number.isFinite)) {
        rangePoints.push({ x, y });
        rangePoints.push({ x: x + rw, y: y + rh });
      }
    } else if (shape.kind === "text" || shape.kind === "point") {
      const x = Number(shape.x);
      const y = Number(shape.y);
      if ([x, y].every(Number.isFinite)) rangePoints.push({ x, y });
    }
  });
  if (!rangePoints.length) {
    ctx.fillStyle = "#94a3b8";
    ctx.font = "12px 'IBM Plex Mono', ui-monospace";
    ctx.fillText("space2d: (no points)", 12, 20);
    return;
  }
  const cam = space2d?.camera ?? null;
  let xMin = Number(cam?.x_min);
  let xMax = Number(cam?.x_max);
  let yMin = Number(cam?.y_min);
  let yMax = Number(cam?.y_max);
  if (![xMin, xMax, yMin, yMax].every(Number.isFinite)) {
    xMin = Math.min(...rangePoints.map((p) => p.x));
    xMax = Math.max(...rangePoints.map((p) => p.x));
    yMin = Math.min(...rangePoints.map((p) => p.y));
    yMax = Math.max(...rangePoints.map((p) => p.y));
  }
  const pad = 28;
  const scaleX = (w - pad * 2) / (xMax - xMin || 1);
  const scaleY = (h - pad * 2) / (yMax - yMin || 1);

  ctx.strokeStyle = "#1f2a44";
  ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(pad, pad); ctx.lineTo(pad, h - pad); ctx.lineTo(w - pad, h - pad); ctx.stroke();

  ctx.fillStyle = "#facc15";
  points.forEach((pt) => {
    const x = pad + (pt.x - xMin) * scaleX;
    const y = h - pad - (pt.y - yMin) * scaleY;
    ctx.beginPath(); ctx.arc(x, y, 3, 0, Math.PI * 2); ctx.fill();
  });

  ctx.strokeStyle = "#a78bfa";
  shapes.forEach((shape) => {
    if (!shape) return;
    if (shape.kind === "line") {
      const x1 = pad + (Number(shape.x1) - xMin) * scaleX;
      const y1 = h - pad - (Number(shape.y1) - yMin) * scaleY;
      const x2 = pad + (Number(shape.x2) - xMin) * scaleX;
      const y2 = h - pad - (Number(shape.y2) - yMin) * scaleY;
      ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
    } else if (shape.kind === "circle") {
      const cx = Number(shape.x ?? shape.cx);
      const cy = Number(shape.y ?? shape.cy);
      const r = Number(shape.r);
      if (![cx, cy, r].every(Number.isFinite)) return;
      const x = pad + (cx - xMin) * scaleX;
      const y = h - pad - (cy - yMin) * scaleY;
      const rr = Math.max(1, r * Math.min(scaleX, scaleY));
      ctx.beginPath(); ctx.arc(x, y, rr, 0, Math.PI * 2); ctx.stroke();
    } else if (shape.kind === "rect") {
      const x = Number(shape.x ?? shape.x0);
      const y = Number(shape.y ?? shape.y0);
      const rw = Number(shape.w ?? shape.width);
      const rh = Number(shape.h ?? shape.height);
      if (![x, y, rw, rh].every(Number.isFinite)) return;
      const x0 = pad + (x - xMin) * scaleX;
      const y0 = h - pad - (y - yMin) * scaleY;
      const w0 = rw * scaleX;
      const h0 = rh * scaleY;
      const fill = shape.fill ?? shape.fill_color ?? null;
      const stroke = shape.color ?? shape.stroke ?? "#a78bfa";
      if (fill) { ctx.fillStyle = String(fill); ctx.fillRect(x0, y0 - h0, w0, h0); }
      ctx.strokeStyle = String(stroke);
      ctx.strokeRect(x0, y0 - h0, w0, h0);
    } else if (shape.kind === "text") {
      const x = Number(shape.x);
      const y = Number(shape.y);
      if (![x, y].every(Number.isFinite)) return;
      const text = shape.text ?? shape.label ?? "";
      if (!text) return;
      const x0 = pad + (x - xMin) * scaleX;
      const y0 = h - pad - (y - yMin) * scaleY;
      const size = Number(shape.size);
      const fontSize = Number.isFinite(size) ? Math.max(8, size) : 11;
      ctx.fillStyle = String(shape.color ?? "#e2e8f0");
      ctx.font = `${fontSize}px 'IBM Plex Mono', ui-monospace`;
      ctx.fillText(String(text), x0, y0);
    }
  });

  ctx.fillStyle = "#e2e8f0";
  ctx.font = "11px 'IBM Plex Mono', ui-monospace";
  ctx.fillText("space2d", pad, 16);
}

// ──────────────────────────────────────────────
// Core actions
// ──────────────────────────────────────────────
async function applyLogic() {
  clearError();
  const source = $("ddn-source").value ?? "";
  const body = stripMetaHeader(source);
  try {
    const client = await ensureWasm(body);
    client.updateLogic(body);
    const state = client.getStateParsed();
    renderState(state);
  } catch (err) {
    showError(`로직 적용 오류: ${String(err?.message ?? err)}`);
  }
}

async function stepOnce() {
  const source = $("ddn-source").value ?? "";
  const body = stripMetaHeader(source);
  try {
    const client = await ensureWasm(body);
    const { keys, lastKey, px, py, dt } = gatherInput();
    const state = client.stepOneWithInputParsed(keys, lastKey, px, py, dt);
    renderState(state);
  } catch (err) {
    showError(`스텝 오류: ${String(err?.message ?? err)}`);
  }
}

function startLoop() {
  if (running) return;
  running = true;
  lastFrameMs = null;
  clearError();
  const tick = (ts) => {
    if (!running) { loopHandle = null; return; }
    const now = typeof ts === "number" ? ts : performance.now();
    const fps = Math.max(1, Number($("input-fps")?.value ?? 30) || 30);
    const interval = 1000 / fps;
    if (lastFrameMs !== null && now - lastFrameMs < interval) {
      loopHandle = requestAnimationFrame(tick);
      return;
    }
    lastFrameMs = now;
    stepOnce().catch((err) => {
      showError(`루프 오류: ${String(err?.message ?? err)}`);
      running = false;
      loopHandle = null;
    });
    loopHandle = requestAnimationFrame(tick);
  };
  loopHandle = requestAnimationFrame(tick);
}

function stopLoop() {
  running = false;
  if (loopHandle) {
    cancelAnimationFrame(loopHandle);
    loopHandle = null;
  }
}

// ──────────────────────────────────────────────
// Sample loading
// ──────────────────────────────────────────────
async function loadSampleById(id) {
  const sample = SAMPLES.find((s) => s.id === id);
  if (!sample) {
    console.warn(`[playground] sample not found: id=${id}`);
    return;
  }
  clearError();
  setStatus([`status: loading ${sample.label}...`]);
  console.log(`[playground] loading sample: ${sample.file}`);
  try {
    const cacheBust = `v=${Date.now()}`;
    const res = await fetch(`${sample.file}?${cacheBust}`, { cache: "no-store" });
    if (!res.ok) {
      const msg = `샘플 로드 실패: ${res.status} ${res.statusText}\npath: ${sample.file}`;
      console.error(`[playground] ${msg}`);
      setStatus([`status: sample load failed (${res.status})`]);
      showError(msg);
      return;
    }
    const text = await res.text();
    console.log(`[playground] loaded ${text.length} chars`);
    $("ddn-source").value = text;
    setStatus([`status: "${sample.label}" loaded`, sample.description || ""]);
  } catch (err) {
    const msg = `샘플 로드 오류: ${String(err?.message ?? err)}`;
    console.error(`[playground]`, err);
    setStatus([`status: sample load error`]);
    showError(msg);
  }
}

// ──────────────────────────────────────────────
// Event wiring
// ──────────────────────────────────────────────
function setupEvents() {
  // Guide toggle
  $("btn-guide")?.addEventListener("click", toggleGuide);

  // Sample dropdown
  sampleSelect?.addEventListener("change", () => {
    const id = sampleSelect.value;
    console.log(`[playground] sample selected: id=${id}`);
    if (id) loadSampleById(id).catch((err) => {
      console.error("[playground] unhandled sample load error:", err);
      showError(String(err));
    });
  });

  // WASM init
  $("btn-init")?.addEventListener("click", () => {
    const source = $("ddn-source").value ?? "";
    const body = stripMetaHeader(source);
    ensureWasm(body).catch((err) => {
      const preview = buildSourcePreview(body, 20);
      const preprocessedPreview = buildSourcePreview(lastPreprocessed, 20);
      const header = lastBuildInfo
        ? `${String(err)} | ${lastBuildInfo}`
        : String(err);
      showError([header, "\nsource:", ...preview, "\npreprocessed:", ...preprocessedPreview].join("\n"));
    });
  });

  // Core controls
  $("btn-apply")?.addEventListener("click", () => applyLogic());
  $("btn-step")?.addEventListener("click", () => stepOnce());
  $("btn-start")?.addEventListener("click", startLoop);
  $("btn-stop")?.addEventListener("click", stopLoop);

  // Toggle raw JSON
  toggleRaw?.addEventListener("change", () => {
    if (rawBox) rawBox.style.display = toggleRaw.checked ? "block" : "none";
  });

  // Param toggles
  paramShowFixed64?.addEventListener("change", () => { if (lastState) renderState(lastState); });
  paramShowValue?.addEventListener("change", () => { if (lastState) renderState(lastState); });

  // Graph toggles
  gridToggle?.addEventListener("change", () => renderGraphOrSpace2d(latestGraph, latestSpace2d));
  axisToggle?.addEventListener("change", () => renderGraphOrSpace2d(latestGraph, latestSpace2d));
  patchPreferToggle?.addEventListener("change", () => { if (lastState) renderState(lastState); });

  // Keyboard shortcuts
  document.addEventListener("keydown", (e) => {
    // Ctrl+Enter = step once
    if (e.ctrlKey && e.key === "Enter") {
      e.preventDefault();
      stepOnce();
    }
    // Ctrl+Shift+Enter = apply logic
    if (e.ctrlKey && e.shiftKey && e.key === "Enter") {
      e.preventDefault();
      applyLogic();
    }
  });
}

// ──────────────────────────────────────────────
// Curriculum extension point
// ──────────────────────────────────────────────
// To add curriculum content:
// 1. Add entries to SAMPLES array above with category grouping
// 2. Put .ddn files in ../samples/ directory
// 3. Optionally add guide sections by appending to #guide-curriculum-slot:
//
//    const slot = document.getElementById("guide-curriculum-slot");
//    slot.innerHTML = `<h3>Lesson 1: ...</h3><p>...</p>`;
//
// Or load curriculum data from an external JSON:
//
//    fetch("../curriculum/lessons.json")
//      .then(r => r.json())
//      .then(lessons => { ... populate SAMPLES and guide ... });

// ──────────────────────────────────────────────
// Init
// ──────────────────────────────────────────────
populateSampleDropdown();
setupEvents();

if (window.location.protocol === "file:") {
  setStatus([
    "status: file:// protocol detected",
    "WASM/ES module requires HTTP server.",
    "python -m http.server 8080",
    "then open http://localhost:8080/playground.html",
  ]);
}
