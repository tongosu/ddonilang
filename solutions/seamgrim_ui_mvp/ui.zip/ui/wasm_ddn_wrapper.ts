import type { DdnWasmVm, SeamgrimDerivedState, SeamgrimState, SeamgrimSchemaId } from "./wasm_ddn_types";

const EXPECTED_SCHEMA: SeamgrimSchemaId = "seamgrim.state.v0";

export function parseStateJson(payload: string): SeamgrimState {
  const parsed = JSON.parse(payload) as SeamgrimState;
  if (parsed.schema !== EXPECTED_SCHEMA) {
    throw new Error(`Unexpected schema: ${String(parsed.schema)}`);
  }
  return parsed;
}

function nowMs(): number {
  if (typeof performance !== "undefined" && typeof performance.now === "function") {
    return performance.now();
  }
  return Date.now();
}

export class DdnWasmVmClient {
  private readonly vm: DdnWasmVm;
  private frameId: number;
  private lastStepMs: number | null;

  constructor(vm: DdnWasmVm) {
    this.vm = vm;
    this.frameId = 0;
    this.lastStepMs = null;
  }

  updateLogic(source: string): void {
    this.vm.update_logic(source);
  }

  setRngSeed(seed: number): void {
    this.vm.set_rng_seed(seed);
  }

  setInput(
    keys_pressed: number,
    last_key_name: string,
    pointer_x_i32: number,
    pointer_y_i32: number,
    dt: number
  ): void {
    this.vm.set_input(keys_pressed, last_key_name, pointer_x_i32, pointer_y_i32, dt);
  }

  stepOneParsed(): SeamgrimDerivedState {
    const state = parseStateJson(this.vm.step_one());
    return this.attachDerived(state, true);
  }

  stepOneWithInputParsed(
    keys_pressed: number,
    last_key_name: string,
    pointer_x_i32: number,
    pointer_y_i32: number,
    dt: number
  ): SeamgrimDerivedState {
    const state = parseStateJson(
      this.vm.step_one_with_input(keys_pressed, last_key_name, pointer_x_i32, pointer_y_i32, dt)
    );
    return this.attachDerived(state, true);
  }

  getStateHash(): string {
    return this.vm.get_state_hash();
  }

  getStateParsed(): SeamgrimDerivedState {
    const state = parseStateJson(this.vm.get_state_json());
    return this.attachDerived(state, false);
  }

  private attachDerived(state: SeamgrimState, advance: boolean): SeamgrimDerivedState {
    const now = nowMs();
    const tickTime = this.lastStepMs === null ? 0 : Math.max(0, now - this.lastStepMs);
    if (advance) {
      this.lastStepMs = now;
      const next = { ...state, frame_id: this.frameId, tick_time_ms: tickTime };
      this.frameId += 1;
      return next;
    }
    return { ...state, frame_id: this.frameId, tick_time_ms: 0 };
  }
}
