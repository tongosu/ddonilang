export type SeamgrimSchemaId = "seamgrim.state.v0";

export interface SeamgrimInput {
  keys_pressed: number;
  last_key_name: string;
  pointer_x_i32: number;
  pointer_y_i32: number;
  dt: string;
  rng_seed: number;
}

export interface SeamgrimResources {
  json: Record<string, string>;
  fixed64: Record<string, string>;
  handle: Record<string, string>;
  value: Record<string, string>;
}

export type SeamgrimPatchOp =
  | { op: "set_resource_json"; tag: string; value: string }
  | { op: "set_resource_fixed64"; tag: string; value: string }
  | { op: "set_resource_handle"; tag: string; value: string }
  | { op: "set_resource_value"; tag: string; value: string }
  | { op: "div_assign_resource_fixed64"; tag: string; value: string }
  | { op: "set_component_json"; entity: number; tag: number; value: string }
  | { op: "remove_component"; entity: number; tag: number }
  | { op: "emit_signal"; signal: string; targets: number[] }
  | { op: "guard_violation"; entity: number; rule_id: number };

export interface SeamgrimState {
  schema: SeamgrimSchemaId;
  tick_id: number;
  state_hash: string;
  input: SeamgrimInput;
  resources: SeamgrimResources;
  patch?: SeamgrimPatchOp[];
}

export interface SeamgrimDerivedState extends SeamgrimState {
  frame_id: number;
  tick_time_ms: number;
}

export interface DdnWasmVm {
  update_logic(source: string): void;
  set_rng_seed(seed: number): void;
  set_input(
    keys_pressed: number,
    last_key_name: string,
    pointer_x_i32: number,
    pointer_y_i32: number,
    dt: number
  ): void;
  set_keys_pressed(keys_pressed: number): void;
  set_last_key_name(last_key_name: string): void;
  set_pointer(pointer_x_i32: number, pointer_y_i32: number): void;
  set_dt_f64(dt: number): void;
  step_one(): string;
  step_one_with_input(
    keys_pressed: number,
    last_key_name: string,
    pointer_x_i32: number,
    pointer_y_i32: number,
    dt: number
  ): string;
  get_state_hash(): string;
  get_state_json(): string;
}
